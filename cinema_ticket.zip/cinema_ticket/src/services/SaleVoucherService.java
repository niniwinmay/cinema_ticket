package services;

import java.sql.PreparedStatement;

import config.DBConfig;
import entities.SaleVoucher;
import shared.mapper.Mapper;

public class SaleVoucherService {
	private final Mapper saleVoucherMapper;
	private final DBConfig dbConfig;
	
	public SaleVoucherService() {
		this.saleVoucherMapper = new Mapper();
		this.dbConfig = new DBConfig();
	}
	
	
public void createSaleVoucher(SaleVoucher saleVoucher) {
		
		try {

			PreparedStatement ps = this.dbConfig.getConnection().prepareStatement(
					"INSERT INTO sale_voucher (customer_id,ticket_id,seat_id,total_price,date) VALUES (?,?,?,?,?)");

			ps.setInt(1, saleVoucher.getCustomer().getCustomer_id());
			ps.setInt(2, saleVoucher.getTicket().getTicket_id());
			ps.setInt(3, saleVoucher.getSeat().getSeat_id());
			ps.setDouble(4,saleVoucher.getTotal_price());
			ps.setString(5, saleVoucher.getsaleDate());

			ps.executeUpdate();
			ps.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
