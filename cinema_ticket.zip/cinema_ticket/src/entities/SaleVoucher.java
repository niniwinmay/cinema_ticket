package entities;

public class SaleVoucher {
	private int sale_id;
	private Customer customer;
	private Ticket ticket;
	private Seat seat;
	private double total_price;
	private String saleDate;
	
	public SaleVoucher()
	{
		
	}
	
	public SaleVoucher(int sale_id, Customer customer, Ticket ticket, Seat seat, double total_price, String saleDate) {
		super();
		this.sale_id = sale_id;
		this.customer = customer;
		this.ticket = ticket;
		this.seat = seat;
		this.total_price = total_price;
		this.saleDate = saleDate;
	}



	public int getSale_id() {
		return sale_id;
	}



	public void setSale_id(int sale_id) {
		this.sale_id = sale_id;
	}


	public Customer getCustomer() {
		return customer;
	}



	public void setCustomer(Customer customer) {
		this.customer = customer;
	}



	public Ticket getTicket() {
		return ticket;
	}



	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}



	public Seat getSeat() {
		return seat;
	}



	public void setSeat(Seat seat) {
		this.seat = seat;
	}



	public double getTotal_price() {
		return total_price;
	}
	public void setTotal_price(double total_price) {
		this.total_price = total_price;
	}
	public String getsaleDate() {
		return saleDate;
	}
	public void setsaleDate(String saleDate) {
		this.saleDate = saleDate;
	}
	
	
}
