package forms;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class CinemaForm {

	public JFrame frmFile;
	JMenu mnEntry;
	private JTable tblCinema;
	private DefaultTableModel dtm = new DefaultTableModel();
	JComboBox cboSectionStart;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CinemaForm window = new CinemaForm();
					window.frmFile.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CinemaForm() {
		initialize();
		this.setTableDesign();
		/*
		 * if (CurrentUserHolder.getCurrentUser() == null) { System.out.println();
		 * mnEntry.setEnabled(false); }
		 */
	}

	private void setTableDesign() {
		dtm.addColumn("Schedule ID");
		dtm.addColumn("Section Start Time");
		dtm.addColumn("Section End Time");
		dtm.addColumn("Section Date");
		dtm.addColumn("Theatre");
		this.tblCinema.setModel(dtm);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmFile = new JFrame();
		frmFile.setTitle("Cinema");
		frmFile.setBounds(100, 100, 658, 458);
		frmFile.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmFile.getContentPane().setLayout(null);
		// frmFile.setUndecorated(true);

		JMenuBar menuBar = new JMenuBar();
		frmFile.setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);

		JMenuItem mntmLogin = new JMenuItem("Login");
		mntmLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CredentialInfoForm credentialInfo;
				try {
					credentialInfo = new CredentialInfoForm();
					credentialInfo.frmLoginForm.setVisible(true);
				} catch (Throwable e1) {
					e1.printStackTrace();
				}
				frmFile.setVisible(false);
			}
		});
		mnNewMenu.add(mntmLogin);

		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// JOptionPane.s
				System.exit(0);
			}
		});
		mnNewMenu.add(mntmExit);

		mnEntry = new JMenu("Entry");
		menuBar.add(mnEntry);

		JMenuItem mntmEmployee = new JMenuItem("Employee");
		mntmEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EmployeeForm emp;
				try {
					emp = new EmployeeForm();
					emp.frmEmployeeForm.setVisible(true);
				} catch (Throwable e1) {
					e1.printStackTrace();
				}
				frmFile.setVisible(false);
			}
		});
		mnEntry.add(mntmEmployee);

		JMenuItem mntmTheatre = new JMenuItem("Theatre");
		mntmTheatre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TheatreForm theatreform;
				try {
					theatreform = new TheatreForm();
					theatreform.frameTheatreForm.setVisible(true);
				} catch (Throwable e1) {
					e1.printStackTrace();
				}
				frmFile.setVisible(false);
			}
		});
		mnEntry.add(mntmTheatre);

		JMenuItem mntmCustomer = new JMenuItem("Customer");
		mntmCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustomerForm customerForm;
				try {
					customerForm = new CustomerForm();
					customerForm.frameCustomerRecordForm.setVisible(true);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				frmFile.setVisible(false);
			}
		});
		mnEntry.add(mntmCustomer);

		JMenuItem mntmTicket = new JMenuItem("Ticket");
		mnEntry.add(mntmTicket);

		JMenuItem mntmSeat = new JMenuItem("Seat");
		mnEntry.add(mntmSeat);

		JMenuItem mntmSection = new JMenuItem("Section");
		mnEntry.add(mntmSection);

		JMenuItem mntmMovie = new JMenuItem("Movie");
		mnEntry.add(mntmMovie);

		JMenu mnNewMenu_2 = new JMenu("Process");
		menuBar.add(mnNewMenu_2);

		JMenuItem mntmSale = new JMenuItem("Sale");
		mnNewMenu_2.add(mntmSale);

		JMenuItem mntmSchedule = new JMenuItem("Schedule");
		mnNewMenu_2.add(mntmSchedule);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 164, 614, 195);
		frmFile.getContentPane().add(scrollPane);

		tblCinema = new JTable();
		tblCinema.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scrollPane.setViewportView(tblCinema);

		JButton btnSelectSeat = new JButton("Select Seat");
		btnSelectSeat.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSelectSeat.setBounds(525, 369, 101, 21);
		frmFile.getContentPane().add(btnSelectSeat);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Cinema Ticket System for JAKE", TitledBorder.LEADING, TitledBorder.TOP,
				null, null));
		panel.setBounds(12, 7, 614, 147);
		frmFile.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblMovieName = new JLabel("Movie");
		lblMovieName.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblMovieName.setBounds(12, 29, 50, 18);
		panel.add(lblMovieName);

		JComboBox cboMovie = new JComboBox();
		cboMovie.setToolTipText("");
		cboMovie.setBounds(150, 29, 121, 21);
		panel.add(cboMovie);

		JLabel lblMovieDate = new JLabel("Movie Date");
		lblMovieDate.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblMovieDate.setBounds(355, 29, 74, 18);
		panel.add(lblMovieDate);

		JComboBox cboMovieDate = new JComboBox();
		cboMovieDate.setToolTipText("");
		cboMovieDate.setBounds(472, 29, 121, 21);
		panel.add(cboMovieDate);

		JComboBox cboMovieDate_1 = new JComboBox();
		cboMovieDate_1.setToolTipText("");
		cboMovieDate_1.setBounds(472, 61, 121, 21);
		panel.add(cboMovieDate_1);

		JLabel lblTheatre = new JLabel("Select Theatre");
		lblTheatre.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblTheatre.setBounds(355, 64, 102, 18);
		panel.add(lblTheatre);

		cboSectionStart = new JComboBox();
		cboSectionStart.setToolTipText("");
		cboSectionStart.setBounds(150, 60, 121, 21);
		panel.add(cboSectionStart);

		JLabel lblSectionStart = new JLabel("Section Start Time");
		lblSectionStart.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblSectionStart.setBounds(12, 61, 126, 21);
		panel.add(lblSectionStart);

		JLabel lblSectionEnd = new JLabel("Section End Time");
		lblSectionEnd.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblSectionEnd.setBounds(12, 98, 121, 21);
		panel.add(lblSectionEnd);

		JComboBox cboSectionEnd = new JComboBox();
		cboSectionEnd.setToolTipText("");
		cboSectionEnd.setBounds(150, 99, 121, 21);
		panel.add(cboSectionEnd);
	}
}
