package forms;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import entities.*;
import services.CustomerService;
import services.MovieService;
import services.SaleVoucherService;
import services.TheatreService;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;

public class SaleVoucherForm {

	 JFrame frameVoucher;
	private JTextField txtTicket;
	private JTextField txtAmount;
	private JTextField textSeat;
	private Customer customer;
	private JTextField txtTotalTicket;
	private JTextField txtCusName;
	private JTextField txtPhone;
	private JTextField txtEmail;
	private JTextField txtAddress;
	CustomerService customerService;
	TheatreService theatreService;
	MovieService movieService;
	JLabel lblSaleDate;
	JComboBox cboTheatreName,cboMovieName,cboSchedule;
	private List<Theatre> theatreList=new ArrayList<>();
	private List<Movie> movieList=new ArrayList<>();
	private SaleVoucher saleVoucher;
	private SaleVoucherService saleVoucherService;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SaleVoucherForm window = new SaleVoucherForm();
					window.frameVoucher.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	public SaleVoucherForm() {
		
		initialize();
		this.customerService = new CustomerService();
		this.theatreService = new TheatreService();
		this.saleVoucherService = new SaleVoucherService();
		
		loadTheatreForComboBox();
		
		
	}
	
	private void resetFormData() {
		txtCusName.setText("");
		txtPhone.setText("");
		txtEmail.setText("");
		txtAddress.setText("");
	}

    private void loadTheatreForComboBox() {
        cboTheatreName.addItem("- Select -");
        this.theatreList = this.theatreService.findAllTheatre();
        this.theatreList.forEach(b -> cboTheatreName.addItem(b.getTheatre_name()));
    }
	
	private void initialize() {
		frameVoucher = new JFrame();
		frameVoucher.setTitle("Voucher");
		frameVoucher.setBounds(100, 100, 550, 440);
		frameVoucher.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameVoucher.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.menu);
		panel.setLayout(null);
		panel.setBorder(new TitledBorder(null, "Sale Voucher", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(12, 0, 510, 360);
		frameVoucher.getContentPane().add(panel);

		JLabel lblTheatreName = new JLabel("Theatre Name");
		lblTheatreName.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTheatreName.setBounds(12, 180, 102, 13);
		panel.add(lblTheatreName);

		cboTheatreName = new JComboBox();
		cboTheatreName.setBounds(108, 175, 118, 21);
		panel.add(cboTheatreName);

		JLabel lblMovieName = new JLabel("Movie Name");
		lblMovieName.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblMovieName.setBounds(12, 149, 102, 13);
		panel.add(lblMovieName);

		cboMovieName = new JComboBox();
		cboMovieName.setBounds(108, 144, 118, 21);
		panel.add(cboMovieName);

		JLabel lblScheduleId = new JLabel("Schedule");
		lblScheduleId.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblScheduleId.setBounds(12, 219, 102, 13);
		panel.add(lblScheduleId);

		cboSchedule = new JComboBox();
		cboSchedule.setBounds(108, 214, 118, 21);
		panel.add(cboSchedule);

		JLabel lblTotalTicket = new JLabel("Ticket Number");
		lblTotalTicket.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTotalTicket.setBounds(12, 285, 102, 13);
		panel.add(lblTotalTicket);

		txtTicket = new JTextField();
		txtTicket.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtTicket.setColumns(10);
		txtTicket.setBounds(108, 281, 118, 19);
		panel.add(txtTicket);

		JLabel lblTotalAmount = new JLabel("Total Amount");
		lblTotalAmount.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTotalAmount.setBounds(12, 312, 102, 13);
		panel.add(lblTotalAmount);

		txtAmount = new JTextField();
		txtAmount.setColumns(10);
		txtAmount.setBounds(108, 308, 118, 19);
		panel.add(txtAmount);

		JLabel lblCustomerName = new JLabel("Customer Name");
		lblCustomerName.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblCustomerName.setBounds(24, 63, 102, 13);
		panel.add(lblCustomerName);

		JLabel lblSeatNumber = new JLabel("Seat Number");
		lblSeatNumber.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblSeatNumber.setBounds(12, 256, 102, 13);
		panel.add(lblSeatNumber);

		JLabel lblDate = new JLabel("Date");
		lblDate.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblDate.setBounds(257, 12, 48, 13);
		panel.add(lblDate);

		textSeat = new JTextField();
		textSeat.setColumns(10);
		textSeat.setBounds(108, 252, 118, 19);
		panel.add(textSeat);

		lblSaleDate = new JLabel("");
		lblSaleDate.setBounds(317, 11, 94, 13);
		panel.add(lblSaleDate);
		
		JLabel lblTotalTicket_1 = new JLabel("Total Ticket");
		lblTotalTicket_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTotalTicket_1.setBounds(236, 284, 102, 13);
		panel.add(lblTotalTicket_1);
		
		txtTotalTicket = new JTextField();
		txtTotalTicket.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtTotalTicket.setColumns(10);
		txtTotalTicket.setBounds(309, 281, 118, 19);
		panel.add(txtTotalTicket);
		
		txtCusName = new JTextField();
		txtCusName.setColumns(10);
		txtCusName.setBounds(120, 59, 118, 19);
		panel.add(txtCusName);
		
		JLabel lblPhone = new JLabel("Phone");
		lblPhone.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPhone.setBounds(24, 90, 102, 13);
		panel.add(lblPhone);
		
		txtPhone = new JTextField();
		txtPhone.setColumns(10);
		txtPhone.setBounds(120, 86, 118, 19);
		panel.add(txtPhone);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblEmail.setBounds(264, 63, 53, 13);
		panel.add(lblEmail);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(321, 59, 118, 19);
		panel.add(txtEmail);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAddress.setBounds(264, 89, 53, 13);
		panel.add(lblAddress);
		
		txtAddress = new JTextField();
		txtAddress.setColumns(10);
		txtAddress.setBounds(321, 86, 118, 19);
		panel.add(txtAddress);
		
		JButton btnCustomerCreate = new JButton("Create");
		btnCustomerCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveCustomer();
				txtCusName.enableInputMethods(false);
				txtAddress.enableInputMethods(false);
				txtPhone.enableInputMethods(false);
				txtEmail.enableInputMethods(false);
			}
		});
		btnCustomerCreate.setBounds(331, 115, 91, 21);
		panel.add(btnCustomerCreate);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Creating Customer", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(12, 35, 469, 104);
		panel.add(panel_1);

		JButton btnClose = new JButton("Close");
		btnClose.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnClose.setBounds(431, 370, 91, 21);
		frameVoucher.getContentPane().add(btnClose);

		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (null != saleVoucher && saleVoucher.getSale_id() != 0) {
					setSaleDataFromForm(saleVoucher);
					
                    if (saleVoucher.getTotal_price()!= 0 &&
                            !saleVoucher.getsaleDate().isBlank() &&
                            null != saleVoucher.getCustomer() &&
                            null != saleVoucher.getTicket() &&
                            null != saleVoucher.getSeat()) {
                    	
                        //saleVoucherService.updateSaleVoucher(String.valueOf(saleVoucher.getSale_id()), saleVoucher);
                        //frameMovieCreate.setVisible(false);
                        MovieDetailForm detailForm=new MovieDetailForm();
                        detailForm.frameMovieDetail.setVisible(true);

                    } else {
                        JOptionPane.showMessageDialog(null, "Check Required Field");
                    }
				}else {
					 SaleVoucher saleVoucher = new SaleVoucher();
	                 //setSaleDataFromForm(saleVoucher);
	                 if (saleVoucher.getTotal_price()!= 0 &&
	                            !saleVoucher.getsaleDate().isBlank() &&
	                            null != saleVoucher.getCustomer() &&
	                            null != saleVoucher.getTicket() &&
	                            null != saleVoucher.getSeat()) {
	                    	saveCustomer();
	                    	saleVoucherService.createSaleVoucher(saleVoucher);
						  //frameMovieCreate.setVisible(false);
	                        SaleVoucherRecordForm detailForm=new SaleVoucherRecordForm();
	                        detailForm.saleRecordframe.setVisible(true);
	                      
	                    } else {
	                        JOptionPane.showMessageDialog(null, "Check Required Field");
	                    }
					
				}
				
				
			}
		});
		btnSave.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnSave.setBounds(321, 370, 91, 21);
		frameVoucher.getContentPane().add(btnSave);
	}
	
	private void setSaleDataFromForm(SaleVoucher saleVoucher) {
        saleVoucher.setsaleDate(lblSaleDate.getText());
        
//        Optional<Movie> selectedMovie = movieList.stream()
//                .filter(c -> c.getMovie_name().equals(cboMovieName.getSelectedItem())).findFirst();
//        saleVoucher.setMovie(selectedMovie.orElse(null));
//        
//        Optional<Ticket> selectedTicket = ticketList.stream()
//                .filter(b -> b.getTheatre_name().equals(cboTheatreName.getSelectedItem())).findFirst();
//        saleVoucher.setT(selectedTicket.orElse(null));
//        
//        Optional<Schedule> selectedActress = actressList.stream()
//                .filter(c -> c.getActress_name().equals(cboActress.getSelectedItem())).findFirst();
//        saleVoucher.setActress(selectedActress.orElse(null));
//                
//        saleVoucher.setDuration(txtDuration.getText());
        
        
    }
	
	public void saveCustomer() {
		customer = new Customer();
		customer.setCustomer_name(txtCusName.getText());
		customer.setCustomer_phone(txtPhone.getText());
		customer.setCustomer_email(txtEmail.getText());
		customer.setCustomer_address(txtAddress.getText());
    	if (txtCusName.getText().matches(".*[0-9].*")) {
			JOptionPane.showMessageDialog(null, "Name must be String");
		} else if (!customer.getCustomer_name().isBlank() && !customer.getCustomer_phone().isBlank() && !customer.getCustomer_email().isBlank() && !customer.getCustomer_address().isBlank()) {
			customerService.createCustomer(customer);
			JOptionPane.showMessageDialog(null, "Save Successfully!!!");
			//resetFormData();
			//loadAllCustomers(Optional.empty());
		
		} else {
			JOptionPane.showMessageDialog(null, "Enter RequiredField");
		}
	}
}
