package forms;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import java.awt.Color;

public class SaleVoucherRecordForm {

	 JFrame saleRecordframe;
	private JTable table;
	private JTextField textField;
	private JButton btnBack;
	private JPanel panel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SaleVoucherRecordForm window = new SaleVoucherRecordForm();
					window.saleRecordframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SaleVoucherRecordForm() {
		initialize();
	}
	
	public void setTableDesign() {
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		saleRecordframe = new JFrame();
		saleRecordframe.setTitle("Sale Voucher Record Form");
		saleRecordframe.setBounds(100, 100, 600, 450);
		saleRecordframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		saleRecordframe.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 78, 564, 288);
		saleRecordframe.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		
		textField = new JTextField();
		textField.setBounds(33, 37, 115, 23);
		saleRecordframe.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setBounds(169, 36, 89, 23);
		saleRecordframe.getContentPane().add(btnSearch);
		
		JLabel lblNewLabel = new JLabel("Sale Voucher Number");
		lblNewLabel.setBounds(23, 20, 107, 14);
		saleRecordframe.getContentPane().add(lblNewLabel);
		
		btnBack = new JButton("Back");
		btnBack.setBounds(485, 377, 89, 23);
		saleRecordframe.getContentPane().add(btnBack);
		
		panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(10, 11, 289, 62);
		saleRecordframe.getContentPane().add(panel);
	}
}
