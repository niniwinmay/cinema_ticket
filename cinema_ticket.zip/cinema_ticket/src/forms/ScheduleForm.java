package forms;

import java.awt.EventQueue;

import javax.swing.JFrame;

public class ScheduleForm {

	private JFrame frameSchedule;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ScheduleForm window = new ScheduleForm();
					window.frameSchedule.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ScheduleForm() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frameSchedule = new JFrame();
		frameSchedule.setTitle("Schedule");
		frameSchedule.setResizable(false);
		frameSchedule.setBounds(100, 100, 450, 300);
		frameSchedule.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameSchedule.getContentPane().setLayout(null);
	}
}
